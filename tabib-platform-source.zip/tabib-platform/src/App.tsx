import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Navbar } from './components/Navbar'
import { Landing } from './pages/Landing'
import { DoctorSearch } from './pages/DoctorSearch'
import { DoctorProfile } from './pages/DoctorProfile'
import { Auth } from './pages/Auth'
import { ForDoctors } from './pages/ForDoctors'
import { DoctorDashboard } from './pages/dashboard/DoctorDashboard'
import { PatientDashboard } from './pages/dashboard/PatientDashboard'
import { AdminDashboard } from './pages/dashboard/AdminDashboard'

function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div dir="rtl" className="min-h-screen bg-[var(--color-ink)]">
      <Navbar />
      {children}
    </div>
  )
}

function App() {
  return (
    <BrowserRouter basename="/tabib">
      <Routes>
        <Route path="/" element={<PublicLayout><Landing /></PublicLayout>} />
        <Route path="/search" element={<PublicLayout><DoctorSearch /></PublicLayout>} />
        <Route path="/doctor/:id" element={<PublicLayout><DoctorProfile /></PublicLayout>} />
        <Route path="/login" element={<PublicLayout><Auth /></PublicLayout>} />
        <Route path="/for-doctors" element={<PublicLayout><ForDoctors /></PublicLayout>} />

        {/* لوحات التحكم - بدون Navbar العام، إلهن Sidebar خاص */}
        <Route path="/dashboard/doctor" element={<DoctorDashboard />} />
        <Route path="/dashboard/patient" element={<PatientDashboard />} />
        <Route path="/dashboard/admin" element={<AdminDashboard />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
