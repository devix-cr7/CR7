import { Link } from 'react-router-dom'
import { Search, ShieldCheck, Bell, Users } from 'lucide-react'
import { specialties } from '../data/specialties'
import { mockDoctors } from '../data/doctors'
import { DoctorCard } from '../components/DoctorCard'
import { PulseMark } from '../components/PulseMark'
import { MedicalOrb3D } from '../components/MedicalOrb3D'

export function Landing() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-[var(--color-border)]">
        {/* العنصر ثلاثي الأبعاد كخلفية طموحة خلف المحتوى */}
        <div className="absolute inset-0 pointer-events-none opacity-80 flex items-center justify-center">
          <MedicalOrb3D />
        </div>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'linear-gradient(180deg, transparent 0%, var(--color-ink) 88%)' }}
        />

        <div className="relative mx-auto max-w-7xl px-6 pt-20 pb-14 md:pt-28 md:pb-20 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-surface)]/80 backdrop-blur px-4 py-1.5 text-xs text-[var(--color-muted)] mb-8">
            <PulseMark className="w-6 h-3.5 text-[var(--color-brand)]" />
            أكثر من 25 تخصص طبي بمكان وحد
          </div>
          <h1 className="text-4xl md:text-6xl font-semibold tracking-tight text-[var(--color-text)] max-w-3xl mx-auto leading-tight">
            احجز موعدك الطبي
            <br />
            <span
              style={{
                background: 'linear-gradient(90deg, var(--color-brand), var(--color-violet))',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
              }}
            >
              بدون انتظار على التلفون
            </span>
          </h1>
          <p className="mt-6 text-lg text-[var(--color-muted)] max-w-xl mx-auto">
            دور على دكتورك المناسب حسب التخصص أو حتى الأعراض، واحجز موعدك مباشرة - تأكيد فوري وتذكير قبل الموعد.
          </p>

          {/* خانة البحث - العنصر الأبرز بالهيرو */}
          <form className="mt-10 mx-auto max-w-2xl">
            <div className="flex items-center gap-2 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]/90 backdrop-blur-sm p-2.5 shadow-[0_0_0_1px_rgba(0,0,0,0.2),0_20px_60px_-20px_rgba(45,217,196,0.25)] focus-within:border-[var(--color-brand)]/60 transition-colors">
              <Search className="w-5 h-5 text-[var(--color-muted)] mr-2 shrink-0" />
              <input
                type="text"
                placeholder="دور بالتخصص، اسم الدكتور، أو شنو تعاني منه..."
                className="flex-1 bg-transparent outline-none text-sm md:text-base text-[var(--color-text)] placeholder:text-[var(--color-muted)] py-2.5"
              />
              <Link
                to="/search"
                className="rounded-xl bg-[var(--color-brand)] px-6 py-3 text-sm font-medium text-[var(--color-ink)] hover:bg-[var(--color-brand-dim)] transition-colors shrink-0"
              >
                بحث
              </Link>
            </div>
          </form>
        </div>

        {/* التخصصات - مباشرة تحت خانة البحث */}
        <div className="relative mx-auto max-w-7xl px-6 pb-16">
          <p className="text-sm text-[var(--color-muted)] text-center mb-5">أو دور حسب التخصص مباشرة</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 max-w-4xl mx-auto">
            {specialties.map((s) => (
              <Link
                key={s.id}
                to={`/search?specialty=${s.id}`}
                className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)]/80 backdrop-blur-sm px-4 py-4 text-center hover:border-[var(--color-brand)]/50 hover:bg-[var(--color-surface)] transition-colors"
              >
                <span className="text-sm text-[var(--color-text)]">{s.nameAr}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-b border-[var(--color-border)]">
        <div className="mx-auto max-w-7xl px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[var(--color-gold)] mt-0.5 shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-[var(--color-text)]">أطباء موثّقون</h3>
              <p className="text-sm text-[var(--color-muted)] mt-1">نتحقق من رقم النقابة الطبية لكل دكتور قبل ما يظهر بالمنصة</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Bell className="w-5 h-5 text-[var(--color-brand)] mt-0.5 shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-[var(--color-text)]">تذكير تلقائي</h3>
              <p className="text-sm text-[var(--color-muted)] mt-1">إشعار قبل موعدك بيوم وبساعتين، ما راح تنسى</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-[var(--color-success)] mt-0.5 shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-[var(--color-text)]">سكرتير لكل عيادة</h3>
              <p className="text-sm text-[var(--color-muted)] mt-1">موعدك يتراجع من شخص حقيقي، ما هو تأكيد آلي أعمى</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured doctors */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="text-xl font-semibold text-[var(--color-text)]">أطباء موثّقون هالأسبوع</h2>
          <Link to="/search" className="text-sm text-[var(--color-brand)] hover:underline">شوف الكل</Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {mockDoctors.slice(0, 6).map((d) => (
            <DoctorCard key={d.id} doctor={d} />
          ))}
        </div>
      </section>

      {/* For doctors CTA */}
      <section className="border-t border-[var(--color-border)]">
        <div className="mx-auto max-w-7xl px-6 py-16 flex flex-col md:flex-row items-center justify-between gap-6 rounded-2xl">
          <div>
            <h2 className="text-xl font-semibold text-[var(--color-text)]">إنت دكتور أو تدير عيادة؟</h2>
            <p className="text-sm text-[var(--color-muted)] mt-2">سجل عيادتك واستقبل حجوزات جديدة - 14 يوم تجربة مجانية.</p>
          </div>
          <Link to="/for-doctors" className="rounded-xl bg-[var(--color-brand)] px-6 py-3 text-sm font-medium text-[var(--color-ink)] hover:bg-[var(--color-brand-dim)] transition-colors shrink-0">
            سجل عيادتك
          </Link>
        </div>
      </section>
    </div>
  )
}
