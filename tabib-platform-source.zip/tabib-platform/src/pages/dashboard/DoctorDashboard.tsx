import { Calendar, Users, Star, TrendingUp, ShieldCheck } from 'lucide-react'
import { DashboardLayout } from '../../components/DashboardLayout'
import type { NavItem } from '../../components/DashboardLayout'
import { StatCard, StatusBadge, SectionCard } from '../../components/DashboardUI'
import { mockAppointments } from '../../data/appointments'
import { mockDoctors } from '../../data/doctors'

const navItems: NavItem[] = [
  { to: '/dashboard/doctor', label: 'نظرة عامة', icon: TrendingUp },
  { to: '/dashboard/doctor/schedule', label: 'جدول المواعيد', icon: Calendar },
  { to: '/dashboard/doctor/patients', label: 'المرضى', icon: Users },
  { to: '/dashboard/doctor/reviews', label: 'التقييمات', icon: Star },
]

export function DoctorDashboard() {
  const doctor = mockDoctors[0]

  return (
    <DashboardLayout navItems={navItems} roleLabel="حساب دكتور" userName={doctor.fullName}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-[var(--color-text)]">مرحباً، {doctor.fullName}</h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">هذا ملخص نشاطك هذا الأسبوع</p>
        </div>
        {doctor.tier === 'trusted' && (
          <span className="flex items-center gap-1.5 rounded-full bg-[var(--color-gold)]/10 px-3 py-1.5 text-xs text-[var(--color-gold)]">
            <ShieldCheck className="w-3.5 h-3.5" /> باقة موثّق
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Calendar} label="مواعيد هذا الأسبوع" value={12} trend="+3" />
        <StatCard icon={Users} label="إجمالي المرضى" value={186} />
        <StatCard icon={Star} label="متوسط التقييم" value={doctor.rating.toFixed(1)} />
        <StatCard icon={TrendingUp} label="نسبة الحضور" value="92%" />
      </div>

      <SectionCard title="أقرب المواعيد">
        <div className="space-y-2">
          {mockAppointments.map((a) => (
            <div key={a.id} className="flex items-center justify-between rounded-xl border border-[var(--color-border)] px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[var(--color-surface-2)] flex items-center justify-center text-xs font-medium text-[var(--color-text)]">
                  {a.patientName.charAt(0)}
                </div>
                <div>
                  <p className="text-sm text-[var(--color-text)]">{a.patientName}</p>
                  <p className="text-xs text-[var(--color-muted)] font-mono">{a.date} · {a.time}</p>
                </div>
              </div>
              <StatusBadge status={a.status} />
            </div>
          ))}
        </div>
      </SectionCard>
    </DashboardLayout>
  )
}
