import { useState } from 'react'
import { ShieldCheck, Users, LayoutGrid, FileText, Check, X } from 'lucide-react'
import { DashboardLayout } from '../../components/DashboardLayout'
import type { NavItem } from '../../components/DashboardLayout'
import { SectionCard, StatCard, EmptyState } from '../../components/DashboardUI'
import { mockPendingDoctors } from '../../data/appointments'

const navItems: NavItem[] = [
  { to: '/dashboard/admin', label: 'طلبات الأطباء', icon: ShieldCheck },
  { to: '/dashboard/admin/doctors', label: 'كل الأطباء', icon: Users },
  { to: '/dashboard/admin/specialties', label: 'التخصصات', icon: LayoutGrid },
]

export function AdminDashboard() {
  const [pending, setPending] = useState(mockPendingDoctors)

  function decide(id: string) {
    setPending((p) => p.filter((d) => d.id !== id))
  }

  return (
    <DashboardLayout navItems={navItems} roleLabel="حساب أدمن" userName="الإدارة">
      <h1 className="text-xl font-semibold text-[var(--color-text)] mb-6">مراجعة طلبات تسجيل الأطباء</h1>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={ShieldCheck} label="طلبات معلقة" value={pending.length} />
        <StatCard icon={Users} label="أطباء موافَق عليهم" value={214} />
        <StatCard icon={FileText} label="طلبات هذا الشهر" value={9} />
      </div>

      <SectionCard title="بانتظار المراجعة">
        {pending.length === 0 ? (
          <EmptyState icon={ShieldCheck} title="ما أكو طلبات معلقة" description="كل الطلبات الحالية تمت مراجعتها" />
        ) : (
          <div className="space-y-3">
            {pending.map((d) => (
              <div key={d.id} className="flex items-center justify-between rounded-xl border border-[var(--color-border)] px-4 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-surface-2)] flex items-center justify-center text-sm font-medium text-[var(--color-text)]">
                    {d.fullName.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm text-[var(--color-text)]">{d.fullName}</p>
                    <p className="text-xs text-[var(--color-brand)]">{d.specialtyAr} · {d.city}</p>
                    <p className="text-xs text-[var(--color-muted)] font-mono mt-0.5">رقم النقابة: {d.licenseNumber}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => decide(d.id)}
                    className="flex items-center gap-1.5 rounded-lg bg-[var(--color-success)]/10 text-[var(--color-success)] px-3 py-2 text-xs font-medium hover:bg-[var(--color-success)]/20 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" /> قبول
                  </button>
                  <button
                    onClick={() => decide(d.id)}
                    className="flex items-center gap-1.5 rounded-lg bg-[var(--color-danger)]/10 text-[var(--color-danger)] px-3 py-2 text-xs font-medium hover:bg-[var(--color-danger)]/20 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" /> رفض
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>
    </DashboardLayout>
  )
}
