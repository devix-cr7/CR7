import { Calendar, Bell, User, Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import { DashboardLayout } from '../../components/DashboardLayout'
import type { NavItem } from '../../components/DashboardLayout'
import { StatusBadge, SectionCard, EmptyState } from '../../components/DashboardUI'
import { mockPatientAppointments } from '../../data/appointments'

const navItems: NavItem[] = [
  { to: '/dashboard/patient', label: 'مواعيدي', icon: Calendar },
  { to: '/dashboard/patient/notifications', label: 'الإشعارات', icon: Bell },
  { to: '/dashboard/patient/profile', label: 'حسابي', icon: User },
]

export function PatientDashboard() {
  const upcoming = mockPatientAppointments.filter((a) => a.status !== 'completed' && a.status !== 'cancelled')
  const past = mockPatientAppointments.filter((a) => a.status === 'completed' || a.status === 'cancelled')

  return (
    <DashboardLayout navItems={navItems} roleLabel="حساب مريض" userName="أحمد كريم">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-semibold text-[var(--color-text)]">مواعيدي</h1>
        <Link to="/search" className="flex items-center gap-2 rounded-xl bg-[var(--color-brand)] px-4 py-2.5 text-sm font-medium text-[var(--color-ink)] hover:bg-[var(--color-brand-dim)] transition-colors">
          <Search className="w-4 h-4" /> احجز موعد جديد
        </Link>
      </div>

      <SectionCard title="المواعيد القادمة">
        {upcoming.length === 0 ? (
          <EmptyState icon={Calendar} title="ما عندك مواعيد قادمة" description="دور على دكتور واحجز موعدك الأول" />
        ) : (
          <div className="space-y-2">
            {upcoming.map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-xl border border-[var(--color-border)] px-4 py-3">
                <div>
                  <p className="text-sm text-[var(--color-text)]">{a.doctorName}</p>
                  <p className="text-xs text-[var(--color-brand)]">{a.specialtyAr}</p>
                  <p className="text-xs text-[var(--color-muted)] font-mono mt-1">{a.date} · {a.time}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <div className="mt-6">
        <SectionCard title="سجل المواعيد السابقة">
          <div className="space-y-2">
            {past.map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-xl border border-[var(--color-border)] px-4 py-3 opacity-70">
                <div>
                  <p className="text-sm text-[var(--color-text)]">{a.doctorName}</p>
                  <p className="text-xs text-[var(--color-muted)] font-mono mt-1">{a.date} · {a.time}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </DashboardLayout>
  )
}
