import type { ReactNode } from 'react'
import type { LucideIcon } from 'lucide-react'

export function StatCard({ icon: Icon, label, value, trend }: { icon: LucideIcon; label: string; value: string | number; trend?: string }) {
  return (
    <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
      <div className="flex items-center justify-between">
        <div className="w-9 h-9 rounded-lg bg-[var(--color-brand)]/10 flex items-center justify-center">
          <Icon className="w-4.5 h-4.5 text-[var(--color-brand)]" />
        </div>
        {trend && <span className="text-xs text-[var(--color-success)]">{trend}</span>}
      </div>
      <p className="text-2xl font-semibold text-[var(--color-text)] mt-4 font-mono">{value}</p>
      <p className="text-xs text-[var(--color-muted)] mt-1">{label}</p>
    </div>
  )
}

const statusStyles: Record<string, string> = {
  pending: 'bg-[var(--color-gold)]/10 text-[var(--color-gold)]',
  confirmed: 'bg-[var(--color-success)]/10 text-[var(--color-success)]',
  approved: 'bg-[var(--color-success)]/10 text-[var(--color-success)]',
  cancelled: 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]',
  rejected: 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]',
  completed: 'bg-[var(--color-muted)]/10 text-[var(--color-muted)]',
}

const statusLabels: Record<string, string> = {
  pending: 'قيد الانتظار',
  confirmed: 'مؤكد',
  approved: 'موافَق عليه',
  cancelled: 'ملغى',
  rejected: 'مرفوض',
  completed: 'مكتمل',
}

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${statusStyles[status] ?? 'bg-[var(--color-surface-2)] text-[var(--color-muted)]'}`}>
      {statusLabels[status] ?? status}
    </span>
  )
}

export function EmptyState({ icon: Icon, title, description }: { icon: LucideIcon; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 rounded-2xl border border-dashed border-[var(--color-border)]">
      <Icon className="w-8 h-8 text-[var(--color-muted)] mb-3" />
      <p className="text-sm text-[var(--color-text)]">{title}</p>
      <p className="text-xs text-[var(--color-muted)] mt-1">{description}</p>
    </div>
  )
}

export function SectionCard({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
      <div className="flex items-center justify-between mb-5">
        <h2 className="font-medium text-[var(--color-text)]">{title}</h2>
        {action}
      </div>
      {children}
    </div>
  )
}
