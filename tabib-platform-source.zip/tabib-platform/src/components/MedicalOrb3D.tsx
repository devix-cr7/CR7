export function MedicalOrb3D() {
  return (
    <div className="orb-scene relative w-full h-full flex items-center justify-center" aria-hidden="true">
      <div className="orb-wrapper relative w-[340px] h-[340px]">
        {/* توهج خلفي */}
        <div
          className="absolute inset-0 rounded-full blur-3xl opacity-25"
          style={{
            background: 'radial-gradient(circle, var(--color-brand) 0%, var(--color-violet) 45%, transparent 70%)',
          }}
        />

        {/* الحلقات الدوارة ثلاثية الأبعاد */}
        <div className="absolute inset-0 flex items-center justify-center" style={{ transformStyle: 'preserve-3d' }}>
          <div
            className="orb-ring-1 absolute w-[300px] h-[300px] rounded-full border"
            style={{ borderColor: 'color-mix(in oklab, var(--color-brand) 55%, transparent)' }}
          />
          <div
            className="orb-ring-2 absolute w-[240px] h-[240px] rounded-full border"
            style={{ borderColor: 'color-mix(in oklab, var(--color-violet) 55%, transparent)' }}
          />
          <div
            className="orb-ring-3 absolute w-[190px] h-[190px] rounded-full border-2"
            style={{ borderColor: 'color-mix(in oklab, var(--color-brand) 35%, transparent)' }}
          />

          {/* نقاط تدور بمدار (تمثل خلايا/بيانات حيوية) */}
          <div className="orb-ring-1 absolute w-[300px] h-[300px]">
            <div
              className="orbit-dot absolute w-3 h-3 rounded-full"
              style={{ background: 'var(--color-brand)', boxShadow: '0 0 12px var(--color-brand)' }}
            />
          </div>
          <div className="orb-ring-2 absolute w-[240px] h-[240px]">
            <div
              className="orbit-dot absolute w-2.5 h-2.5 rounded-full"
              style={{ background: 'var(--color-violet)', boxShadow: '0 0 10px var(--color-violet)', animationDirection: 'reverse' }}
            />
          </div>
        </div>

        {/* النواة النابضة بالمنتصف */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="orb-core w-24 h-24 rounded-full flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, var(--color-brand), var(--color-violet))',
              boxShadow: '0 0 60px color-mix(in oklab, var(--color-brand) 60%, transparent)',
            }}
          >
            <svg viewBox="0 0 24 24" className="w-10 h-10 text-[var(--color-ink)]" fill="none">
              <path d="M12 21s-7-4.35-9.5-8.5C.7 8.9 2.4 5 6 5c2 0 3.5 1.2 4.2 2.7L12 10l1.8-2.3C14.5 6.2 16 5 18 5c3.6 0 5.3 3.9 3.5 7.5C19 16.65 12 21 12 21z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" fill="var(--color-ink)" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  )
}
