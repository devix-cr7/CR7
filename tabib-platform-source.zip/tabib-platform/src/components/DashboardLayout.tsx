import type { ReactNode } from 'react'
import { NavLink } from 'react-router-dom'
import type { LucideIcon } from 'lucide-react'
import { PulseMark } from './PulseMark'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
}

export function DashboardLayout({
  navItems,
  roleLabel,
  userName,
  children,
}: {
  navItems: NavItem[]
  roleLabel: string
  userName: string
  children: ReactNode
}) {
  return (
    <div dir="rtl" className="min-h-screen flex bg-[var(--color-ink)]">
      <aside className="w-64 shrink-0 border-l border-[var(--color-border)] bg-[var(--color-surface)] flex flex-col">
        <div className="h-16 flex items-center gap-2.5 px-6 border-b border-[var(--color-border)]">
          <PulseMark className="w-9 h-5 text-[var(--color-brand)]" />
          <span className="text-lg font-semibold text-[var(--color-text)]">طبيب.</span>
        </div>

        <nav className="flex-1 px-3 py-6 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                  isActive
                    ? 'bg-[var(--color-brand)]/10 text-[var(--color-brand)]'
                    : 'text-[var(--color-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-surface-2)]'
                }`
              }
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-[var(--color-border)] flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[var(--color-surface-2)] flex items-center justify-center text-sm font-medium text-[var(--color-text)]">
            {userName.charAt(0)}
          </div>
          <div className="min-w-0">
            <p className="text-sm text-[var(--color-text)] truncate">{userName}</p>
            <p className="text-xs text-[var(--color-muted)]">{roleLabel}</p>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto px-8 py-8">{children}</div>
      </main>
    </div>
  )
}
