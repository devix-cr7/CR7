export interface AppointmentRow {
  id: string
  patientName: string
  doctorName?: string
  specialtyAr?: string
  date: string
  time: string
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed'
}

export const mockAppointments: AppointmentRow[] = [
  { id: 'a1', patientName: 'حسين علي', date: '2026-07-23', time: '10:00', status: 'confirmed' },
  { id: 'a2', patientName: 'مريم كاظم', date: '2026-07-23', time: '11:00', status: 'pending' },
  { id: 'a3', patientName: 'أسامة فاضل', date: '2026-07-24', time: '17:00', status: 'confirmed' },
  { id: 'a4', patientName: 'رنا سالم', date: '2026-07-22', time: '18:00', status: 'completed' },
  { id: 'a5', patientName: 'كرار جبار', date: '2026-07-21', time: '09:00', status: 'cancelled' },
]

export const mockPatientAppointments: AppointmentRow[] = [
  { id: 'p1', patientName: 'أنت', doctorName: 'د. أحمد الجبوري', specialtyAr: 'قلبية', date: '2026-07-25', time: '17:00', status: 'confirmed' },
  { id: 'p2', patientName: 'أنت', doctorName: 'د. سارة العبيدي', specialtyAr: 'أطفال', date: '2026-07-28', time: '10:00', status: 'pending' },
  { id: 'p3', patientName: 'أنت', doctorName: 'د. مصطفى العامري', specialtyAr: 'أسنان', date: '2026-06-30', time: '11:00', status: 'completed' },
]

export interface PendingDoctorRow {
  id: string
  fullName: string
  specialtyAr: string
  city: string
  licenseNumber: string
  submittedAt: string
}

export const mockPendingDoctors: PendingDoctorRow[] = [
  { id: 'd1', fullName: 'د. حيدر منعم', specialtyAr: 'جلدية', city: 'بغداد', licenseNumber: '48213', submittedAt: '2026-07-20' },
  { id: 'd2', fullName: 'د. إيمان صادق', specialtyAr: 'نسائية وتوليد', city: 'كربلاء', licenseNumber: '39012', submittedAt: '2026-07-21' },
]
